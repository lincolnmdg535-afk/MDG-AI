'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Loader2, Sparkles, LogOut, Download, Image as ImageIcon, Lightbulb, ChevronRight } from 'lucide-react'

interface User {
  id: string
  email: string
  name: string | null
  credits: number
}

export default function Home() {
  const [user, setUser] = useState<User | null>(null)
  const [isRegistering, setIsRegistering] = useState(false)
  const [loading, setLoading] = useState(false)
  const [generating, setGenerating] = useState(false)
  const [generatedImage, setGeneratedImage] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    prompt: ''
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
  }

  const handleAuth = async (type: 'login' | 'register') => {
    setLoading(true)
    setError(null)

    try {
      const endpoint = type === 'register' ? '/api/auth/register' : '/api/auth/login'
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: formData.email,
          password: formData.password,
          name: formData.name || undefined
        })
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Erreur d\'authentification')
      }

      setUser(data.user)
      setFormData({ email: '', password: '', name: '', prompt: '' })
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Une erreur est survenue')
    } finally {
      setLoading(false)
    }
  }

  const handleGenerate = async () => {
    if (!user || !formData.prompt.trim()) return

    setGenerating(true)
    setError(null)

    try {
      const response = await fetch('/api/images/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: formData.prompt,
          userId: user.id
        })
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Erreur de génération')
      }

      setGeneratedImage(data.imageUrl)
      setUser(prev => prev ? { ...prev, credits: data.credits } : null)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Une erreur est survenue')
    } finally {
      setGenerating(false)
    }
  }

  const handleLogout = () => {
    setUser(null)
    setGeneratedImage(null)
    setError(null)
  }

  const handleDownload = () => {
    if (generatedImage) {
      const link = document.createElement('a')
      link.href = generatedImage
      link.download = `generated-image-${Date.now()}.png`
      link.click()
    }
  }

  // Auth View
  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-xl">
          <CardHeader className="space-y-2 text-center">
            <div className="flex justify-center mb-4">
              <div className="p-3 bg-gradient-to-br from-purple-600 to-blue-600 rounded-xl">
                <Sparkles className="h-8 w-8 text-white" />
              </div>
            </div>
            <CardTitle className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              MDG IS GENERATING AN IMAGE
            </CardTitle>
            <CardDescription>
              Générez des images incroyables avec l'intelligence artificielle
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="login">Connexion</TabsTrigger>
                <TabsTrigger value="register">Inscription</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login" className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Email</label>
                  <Input
                    type="email"
                    name="email"
                    placeholder="votre@email.com"
                    value={formData.email}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Mot de passe</label>
                  <Input
                    type="password"
                    name="password"
                    placeholder="••••••••"
                    value={formData.password}
                    onChange={handleInputChange}
                  />
                </div>
                {error && (
                  <div className="p-3 bg-red-50 text-red-600 text-sm rounded-lg">
                    {error}
                  </div>
                )}
                <Button
                  onClick={() => handleAuth('login')}
                  disabled={loading}
                  className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                >
                  {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Se connecter
                </Button>
              </TabsContent>
              
              <TabsContent value="register" className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Nom (optionnel)</label>
                  <Input
                    type="text"
                    name="name"
                    placeholder="Votre nom"
                    value={formData.name}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Email</label>
                  <Input
                    type="email"
                    name="email"
                    placeholder="votre@email.com"
                    value={formData.email}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Mot de passe</label>
                  <Input
                    type="password"
                    name="password"
                    placeholder="••••••••"
                    value={formData.password}
                    onChange={handleInputChange}
                  />
                </div>
                <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                  <p className="text-sm text-purple-700 font-medium">
                    🎁 30 crédits gratuits offerts !
                  </p>
                  <p className="text-xs text-purple-600 mt-1">
                    Chaque image générée consomme 1 crédit
                  </p>
                </div>
                {error && (
                  <div className="p-3 bg-red-50 text-red-600 text-sm rounded-lg">
                    {error}
                  </div>
                )}
                <Button
                  onClick={() => handleAuth('register')}
                  disabled={loading}
                  className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                >
                  {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  S'inscrire
                </Button>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Image Generation View
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-br from-purple-600 to-blue-600 rounded-lg">
              <Sparkles className="h-5 w-5 text-white" />
            </div>
            <h1 className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              MDG IS GENERATING AN IMAGE
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg border border-purple-200">
              <ImageIcon className="h-4 w-4 text-purple-600" />
              <span className="text-sm font-medium text-purple-700">
                {user.credits} crédit{user.credits > 1 ? 's' : ''} restant{user.credits > 1 ? 's' : ''}
              </span>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={handleLogout}
              className="gap-2"
            >
              <LogOut className="h-4 w-4" />
              Déconnexion
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Left Panel - Input */}
          <div className="space-y-6">
            <Card className="shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-purple-600" />
                  Générateur d'images
                </CardTitle>
                <CardDescription>
                  Décrivez l'image que vous souhaitez générer
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Votre prompt</label>
                  <Textarea
                    placeholder="Un chaton mignon jouant dans un jardin fleuri, lumière du soleil, fond flou..."
                    value={formData.prompt}
                    onChange={(e) => setFormData(prev => ({ ...prev, prompt: e.target.value }))}
                    disabled={generating || user.credits <= 0}
                    className="min-h-[120px] text-base resize-none"
                    rows={5}
                  />
                  <p className="text-xs text-gray-500">
                    {formData.prompt.length} caractères
                  </p>
                </div>

                <div className="p-4 bg-gray-50 rounded-lg space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Crédits disponibles:</span>
                    <span className={`font-bold ${user.credits <= 3 ? 'text-red-600' : 'text-purple-600'}`}>
                      {user.credits}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">Coût par génération:</span>
                    <span className="font-medium">1 crédit</span>
                  </div>
                </div>

                {user.credits <= 0 && (
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <p className="text-sm text-red-700 font-medium">
                      ⚠️ Crédits insuffisants
                    </p>
                    <p className="text-xs text-red-600 mt-1">
                      Vous n'avez plus de crédits pour générer des images.
                    </p>
                  </div>
                )}

                {error && (
                  <div className="p-3 bg-red-50 text-red-600 text-sm rounded-lg">
                    {error}
                  </div>
                )}

                <Button
                  onClick={handleGenerate}
                  disabled={generating || !formData.prompt.trim() || user.credits <= 0}
                  className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                  size="lg"
                >
                  {generating ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Génération en cours...
                    </>
                  ) : (
                    <>
                      <Sparkles className="mr-2 h-5 w-5" />
                      Générer l'image
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Tips Section */}
            <Card className="shadow-lg border-purple-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Lightbulb className="h-5 w-5 text-yellow-500" />
                  Conseils pour de meilleurs résultats
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <h4 className="text-sm font-semibold text-purple-700">Exemples de prompts:</h4>
                  <div className="space-y-2">
                    {[
                      "Un chaton mignon jouant dans un jardin fleuri avec des marguerites, lumière dorée du crépuscule",
                      "Un paysage de montagne majestueux avec un lac au premier plan, ciel bleu nuageux, style photographie professionnelle",
                      "Un astronaute sur Mars regardant la Terre dans le ciel, lumière solaire intense, réaliste et détaillé"
                    ].map((example, index) => (
                      <button
                        key={index}
                        onClick={() => setFormData(prev => ({ ...prev, prompt: example }))}
                        disabled={generating}
                        className="w-full text-left p-3 text-sm bg-purple-50 hover:bg-purple-100 rounded-lg border border-purple-200 transition-colors flex items-start gap-2"
                      >
                        <ChevronRight className="h-4 w-4 text-purple-600 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700">{example}</span>
                      </button>
                    ))}
                  </div>
                </div>
                <div className="space-y-2">
                  <h4 className="text-sm font-semibold text-purple-700">✨ Règles d'or:</h4>
                  <ul className="space-y-1 text-xs text-gray-600">
                    <li>• Décrivez le sujet principal en détail</li>
                    <li>• Ajoutez des informations sur le style (réaliste, peinture, photographie...)</li>
                    <li>• Mentionnez la lumière et l'ambiance</li>
                    <li>• Précisez le cadre (premier plan, arrière-plan...)</li>
                    <li>• Utilisez des adjectifs descriptifs (vibrant, sombre, coloré...)</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Panel - Result */}
          <Card className="shadow-xl">
            <CardHeader>
              <CardTitle>Image générée</CardTitle>
              <CardDescription>
                Votre image apparaîtra ici
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="aspect-square bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg flex items-center justify-center overflow-hidden">
                {generatedImage ? (
                  <img
                    src={generatedImage}
                    alt="Image générée"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="text-center p-8">
                    <ImageIcon className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-400">
                      Entrez un prompt et cliquez sur "Générer l'image"
                    </p>
                  </div>
                )}
              </div>
              
              {generatedImage && (
                <div className="mt-4">
                  <Button
                    onClick={handleDownload}
                    variant="outline"
                    className="w-full gap-2"
                  >
                    <Download className="h-4 w-4" />
                    Télécharger l'image
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
