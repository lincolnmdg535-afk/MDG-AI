import { db } from '@/lib/db'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { email, password } = body

    if (!email || !password) {
      return Response.json(
        { error: 'Email et mot de passe requis' },
        { status: 400 }
      )
    }

    // Trouver l'utilisateur
    const user = await db.user.findUnique({
      where: { email }
    })

    if (!user || user.password !== password) {
      return Response.json(
        { error: 'Email ou mot de passe incorrect' },
        { status: 401 }
      )
    }

    // Retourner l'utilisateur sans le mot de passe
    const { password: _, ...userWithoutPassword } = user

    return Response.json({ user: userWithoutPassword })
  } catch (error) {
    console.error('Erreur de connexion:', error)
    return Response.json(
      { error: 'Erreur lors de la connexion' },
      { status: 500 }
    )
  }
}
