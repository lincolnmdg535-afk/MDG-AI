import { db } from '@/lib/db'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { email, password, name } = body

    if (!email || !password) {
      return Response.json(
        { error: 'Email et mot de passe requis' },
        { status: 400 }
      )
    }

    // Vérifier si l'utilisateur existe déjà
    const existingUser = await db.user.findUnique({
      where: { email }
    })

    if (existingUser) {
      return Response.json(
        { error: 'Cet email est déjà utilisé' },
        { status: 400 }
      )
    }

    // Créer l'utilisateur avec 30 crédits gratuits
    const user = await db.user.create({
      data: {
        email,
        password, // Dans une vraie app, on devrait hasher le mot de passe
        name: name || null,
        credits: 30
      },
      select: {
        id: true,
        email: true,
        name: true,
        credits: true
      }
    })

    return Response.json({ user })
  } catch (error) {
    console.error('Erreur d\'inscription:', error)
    return Response.json(
      { error: 'Erreur lors de l\'inscription' },
      { status: 500 }
    )
  }
}
