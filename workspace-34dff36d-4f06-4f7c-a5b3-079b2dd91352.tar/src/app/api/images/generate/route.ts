import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'

// Fonction pour optimiser le prompt tout en conservant l'intention de l'utilisateur
function optimizePrompt(userPrompt: string): string {
  let optimized = userPrompt.trim()

  // Liste de mots-clés de qualité à vérifier
  const qualityKeywords = [
    'high quality', 'detailed', 'professional', 'beautiful', 'stunning',
    'photorealistic', 'realistic', 'detailed', 'sharp', 'clear',
    'haute qualité', 'détaillé', 'professionnel', 'belle', 'époustouflant',
    'photoréaliste', 'réaliste', 'net', 'claire'
  ]

  // Vérifier si le prompt contient déjà des mots-clés de qualité
  const hasQualityKeyword = qualityKeywords.some(keyword =>
    optimized.toLowerCase().includes(keyword.toLowerCase())
  )

  // Si pas de mot-clé de qualité, en ajouter un à la fin
  if (!hasQualityKeyword) {
    optimized += ', high quality, detailed'
  }

  // Nettoyer les doubles espaces et virgules multiples
  optimized = optimized.replace(/\s+/g, ' ').replace(/,+/g, ',').replace(/,\s*$/, '')

  return optimized
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { prompt, userId } = body

    if (!prompt || !userId) {
      return Response.json(
        { error: 'Prompt et utilisateur requis' },
        { status: 400 }
      )
    }

    // Vérifier les crédits de l'utilisateur
    const user = await db.user.findUnique({
      where: { id: userId }
    })

    if (!user) {
      return Response.json(
        { error: 'Utilisateur non trouvé' },
        { status: 404 }
      )
    }

    if (user.credits <= 0) {
      return Response.json(
        { error: 'Crédits insuffisants', credits: user.credits },
        { status: 403 }
      )
    }

    // Optimiser le prompt pour une meilleure génération
    const optimizedPrompt = optimizePrompt(prompt)

    // Générer l'image avec le SDK en utilisant le prompt optimisé
    const zai = await ZAI.create()
    const response = await zai.images.generations.create({
      prompt: optimizedPrompt,
      size: '1024x1024'
    })

    const imageBase64 = response.data[0].base64

    // Créer une URL data pour l'image
    const imageUrl = `data:image/png;base64,${imageBase64}`

    // Déduire 1 crédit et sauvegarder l'image
    await db.user.update({
      where: { id: userId },
      data: {
        credits: user.credits - 1
      }
    })

    // Sauvegarder l'image générée
    await db.image.create({
      data: {
        prompt,
        imageData: imageBase64,
        userId
      }
    })

    // Récupérer les crédits mis à jour
    const updatedUser = await db.user.findUnique({
      where: { id: userId },
      select: { credits: true }
    })

    return Response.json({
      success: true,
      imageUrl,
      credits: updatedUser?.credits || 0
    })
  } catch (error) {
    console.error('Erreur de génération d\'image:', error)
    return Response.json(
      { error: 'Erreur lors de la génération de l\'image' },
      { status: 500 }
    )
  }
}
